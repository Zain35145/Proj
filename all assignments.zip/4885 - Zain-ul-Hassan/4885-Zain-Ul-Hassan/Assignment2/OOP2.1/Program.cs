﻿using System;
using System.Collections.Generic;
// here we are defining BankAccount Class with properties AccountNumber, AccountHolder, and Bak=lance
// the Balance property has a protected setter meaning it can be modified in the child classes
class BankAccount
{
    public string AccountNumber { get; }
    public string AccountHolder { get; }
    public decimal Balance { get; protected set; }
    // the constructor of BankAccount class is defined and it initializes the parameters 

    public BankAccount(string accountNumber, string accountHolder, decimal balance = 0)
    {
        AccountNumber = accountNumber;
        AccountHolder = accountHolder;
        Balance = balance;
    }
    // this virtual method is allowing depositing an amount and increases the Balance by amount 
    public virtual void Deposit(decimal amount)
    {
        Balance += amount;
    }
    // this method allows the withdrawal if the withdrawal amount is less than the balance present
    // otherwise it is representing a relevant message insufficient balance
    public virtual void Withdraw(decimal amount)
    {
        if (amount <= Balance)
        {
            Balance -= amount;
        }
        else
        {
            Console.WriteLine("Insufficient balance.");
        }
    }
    //this method is displaying AccountNumber, AccountHolder, and Balance
    public void DisplayAccountInfo()
    {
        Console.WriteLine($"Account Number: {AccountNumber}");
        Console.WriteLine($"Account Holder: {AccountHolder}");
        Console.WriteLine($"Balance: {Balance}");
    }
}
//Here SavingsAccount is defined as child class of BankAccount

class SavingsAccount : BankAccount
{
    // an additional property is InterestRate is defined 
    public decimal InterestRate { get; }
    // the constructor for SavingsAccount is initializing the InterestRate and Calling the remaining methods from the parent class
    public SavingsAccount(string accountNumber, string accountHolder, decimal interestRate, decimal balance = 0)
        : base(accountNumber, accountHolder, balance)
    {
        InterestRate = interestRate;
    }
    // The deposit method in the SavingsAccount Class is overriding the Deposit Method in BankAccount 
    //It calculates the InterestRate as well and adding the amount to the Balance
    public override void Deposit(decimal amount)
    {
        decimal interest = amount * (InterestRate / 100);
        Balance += amount + interest;
    }
}
// This CheckingAccount class is inherited from the BankAccount class and is not performing any additiional methods
class CheckingAccount : BankAccount
{
    public CheckingAccount(string accountNumber, string accountHolder, decimal balance = 0)
        : base(accountNumber, accountHolder, balance)
    {
    }
    // Here again the Withdraw method is being overridden 
    public override void Withdraw(decimal amount)
    {
        
        Balance -= amount;
    }
}
// Bank class is created to manage collection of BankAccounts
class Bank
{
    // a private list is created inside the Bank class for adding BankAccounts to the list accounts
    private List<BankAccount> accounts;
    // the constructor initializes the accounts list as a new instance
    public Bank()
    {
        accounts = new List<BankAccount>();
    }
    // The AddAccount method is taking a BankAcount object and adding it to accounts list

    public void AddAccount(BankAccount account)
    {
        accounts.Add(account);
    }
    //the DepositToAccount method is finding the account with specified accountNumber by 
    //implementing the FindAccount method. If the account is found we call the Deposit method and add amount 
    //to the balance otherwise represents a relevant message as account not found

    public void DepositToAccount(string accountNumber, decimal amount)
    {
        BankAccount account = FindAccount(accountNumber);
        if (account != null)
        {
            account.Deposit(amount);
        }
        else
        {
            Console.WriteLine("Account not found.");
        }
    }
    //The WithDrawFromAccount method is finding the account number with a specified name
    //and thyen checkinbg if itb is not null allow the withdrawal otherwise return insufficient balance

    public void WithdrawFromAccount(string accountNumber, decimal amount)
    {
        BankAccount account = FindAccount(accountNumber);
        if (account != null)
        {
            account.Withdraw(amount);
        }
        else
        {
            Console.WriteLine("Insufficient Balance.");
        }
    }
    //it is a private method and finding the accountNumber
    //if the accountNumber is not found null is returned
    private BankAccount FindAccount(string accountNumber)
    {
        foreach (BankAccount account in accounts)
        {
            if (account.AccountNumber == accountNumber)
            {
                return account;
            }
        }
        return null;
    }
}

class Program
{
    static void Main(string[] args)
        // a new object bank of class Bank is created 
    {
        Bank bank = new Bank();
        // instances of SavingsAccount and CheckingAccount are savingsAccounts and checkingAccount respectively

        SavingsAccount savingsAccount = new SavingsAccount("SA001", "Zain-ul-Hassan", 2.5m);
        CheckingAccount checkingAccount = new CheckingAccount("CA001", "Jawad Haider");

        // tyhe AddAccount meythod of the Bank Class is called add savingsAccount and checkingAccount to the bank object 
        bank.AddAccount(savingsAccount);
        bank.AddAccount(checkingAccount);
        // the deposit method of each class is called to deposit specific amount
        savingsAccount.Deposit(1000);
        checkingAccount.Deposit(500);
        // the DepositToAccount and WuthdrawFromAccount are called to withdraw or deposit with an extra parameter accountNumber
        bank.DepositToAccount("SA001", 200);
        bank.WithdrawFromAccount("CA001", 1000);
        // Infor of both the accounts is displayed
        savingsAccount.DisplayAccountInfo();
        checkingAccount.DisplayAccountInfo();

        Console.ReadLine();
    }
}
