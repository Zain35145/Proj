﻿using System;
using System.Collections.Generic;
using System.Text;

namespace assign2._4._1
{
    interface ITransaction
    {
        void ExecuteTransaction(decimal amount);
        void PrintTransaction();
    }

}
