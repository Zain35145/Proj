﻿using System;
using System.Collections.Generic;
using System.Text;

namespace assign2._4._1
{
    class Bank
    {
        private Dictionary<string, BankAccount> accounts;

        public Bank()
        {
            accounts = new Dictionary<string, BankAccount>();
        }

        public void AddAccount(BankAccount account)
        {
            accounts.Add(account.AccountNumber, account);
            Console.WriteLine($"Account {account.AccountNumber} added to the bank.");
        }

        public void ProcessTransaction(string accountNumber, decimal amount)
        {
            if (accounts.ContainsKey(accountNumber))
            {
                ITransaction account = accounts[accountNumber] as ITransaction;
                account?.ExecuteTransaction(amount);
            }
            else
            {
                Console.WriteLine("Account not found.");
            }
        }
    }
}
