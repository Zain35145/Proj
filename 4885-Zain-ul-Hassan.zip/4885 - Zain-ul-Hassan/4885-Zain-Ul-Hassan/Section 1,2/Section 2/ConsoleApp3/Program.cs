﻿using System;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            NumbersinArray();
        }
        static void NumbersinArray()
        {
            int[] Numbers = new int[5] { 1, 2, 3, 4, 5 };
            Console.WriteLine("Enter the number to search");
            int searchnumber = Convert.ToInt32(Console.ReadLine());


            bool found = false;
            foreach(int number in Numbers)
            {
                if (searchnumber==number)
                {
                    found = true;
                    break;
                }

            }
            Console.WriteLine(found ? "Number is in array" : "Number is not in array");



        }
        static void Palindrome()
        {
            Console.WriteLine("Enter the string");
            string input = Console.ReadLine();
            string reverse = str
        }
    }
}
