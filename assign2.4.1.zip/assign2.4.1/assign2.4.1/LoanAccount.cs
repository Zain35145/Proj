﻿using System;
using System.Collections.Generic;
using System.Text;

namespace assign2._4._1
{
    class LoanAccount : BankAccount, ITransaction
    {
        private decimal interestRate;

        public LoanAccount(string accountHolderName, decimal interestRate)
            : base(accountHolderName)
        {
            this.interestRate = interestRate;
        }

        public override void CalculateInterest()
        {
            decimal interest = Balance * (interestRate / 100);
            Balance += interest;
            AddTransaction("Interest Added", interest);
        }

        public void ExecuteTransaction(decimal amount)
        {
            Deposit(amount);
        }

        public void PrintTransaction()
        {
            PrintTransactionHistory();
        }
    }
}
