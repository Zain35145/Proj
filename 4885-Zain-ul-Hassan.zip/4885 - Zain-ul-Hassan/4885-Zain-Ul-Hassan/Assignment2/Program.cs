﻿using System;
using System.Collections.Generic;

class BankAccount
{
    public string AccountNumber { get; }
    public string AccountHolder { get; }
    public decimal Balance { get; protected set; }

    public BankAccount(string accountNumber, string accountHolder, decimal balance = 0)
    {
        AccountNumber = accountNumber;
        AccountHolder = accountHolder;
        Balance = balance;
    }

    public virtual void Deposit(decimal amount)
    {
        Balance += amount;
    }

    public virtual void Withdraw(decimal amount)
    {
        if (amount <= Balance)
        {
            Balance -= amount;
        }
        else
        {
            Console.WriteLine("Insufficient balance.");
        }
    }

    public void DisplayAccountInfo()
    {
        Console.WriteLine($"Account Number: {AccountNumber}");
        Console.WriteLine($"Account Holder: {AccountHolder}");
        Console.WriteLine($"Balance: {Balance}");
    }
}

class SavingsAccount : BankAccount
{
    public decimal InterestRate { get; }

    public SavingsAccount(string accountNumber, string accountHolder, decimal interestRate, decimal balance = 0)
        : base(accountNumber, accountHolder, balance)
    {
        InterestRate = interestRate;
    }

    public override void Deposit(decimal amount)
    {
        decimal interest = amount * (InterestRate / 100);
        Balance += amount + interest;
    }
}

class CheckingAccount : BankAccount
{
    public CheckingAccount(string accountNumber, string accountHolder, decimal balance = 0)
        : base(accountNumber, accountHolder, balance)
    {
    }

    public override void Withdraw(decimal amount)
    {
        
        Balance -= amount;
    }
}

class Bank
{
    private List<BankAccount> accounts;

    public Bank()
    {
        accounts = new List<BankAccount>();
    }

    public void AddAccount(BankAccount account)
    {
        accounts.Add(account);
    }

    public void DepositToAccount(string accountNumber, decimal amount)
    {
        BankAccount account = FindAccount(accountNumber);
        if (account != null)
        {
            account.Deposit(amount);
        }
        else
        {
            Console.WriteLine("Account not found.");
        }
    }

    public void WithdrawFromAccount(string accountNumber, decimal amount)
    {
        BankAccount account = FindAccount(accountNumber);
        if (account != null)
        {
            account.Withdraw(amount);
        }
        else
        {
            Console.WriteLine("Account not found.");
        }
    }

    private BankAccount FindAccount(string accountNumber)
    {
        foreach (BankAccount account in accounts)
        {
            if (account.AccountNumber == accountNumber)
            {
                return account;
            }
        }
        return null;
    }
}

class Program
{
    static void Main(string[] args)
    {
        Bank bank = new Bank();

        SavingsAccount savingsAccount = new SavingsAccount("SA001", "Zain-ul-Hassan", 2.5m);
        CheckingAccount checkingAccount = new CheckingAccount("CA001", "Jawad Haider");


        bank.AddAccount(savingsAccount);
        bank.AddAccount(checkingAccount);

        savingsAccount.Deposit(1000);
        checkingAccount.Deposit(500);

        bank.DepositToAccount("SA001", 200);
        bank.WithdrawFromAccount("CA001", 1000);

        savingsAccount.DisplayAccountInfo();
        checkingAccount.DisplayAccountInfo();

        Console.ReadLine();
    }
}
