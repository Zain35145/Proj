﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            //Name();
            //sum();
            //sqrt();
            //Even();
            //nnumber();
            //table();

            //prime();
            //fact();
            //fibo();
          
            Main();
        }
        //static void Name()
        //{
        //    Console.WriteLine("Enter Your Name");
        //    string name = Console.ReadLine();

        //    Console.WriteLine("Hello    " + name);
        //}
        //static void sum()
        //{
        //    Console.WriteLine("Enter the first number");
        //    int num1 = Convert.ToInt32(Console.ReadLine());
        //    Console.WriteLine("Enter the second number");
        //    int num2 = Convert.ToInt32(Console.ReadLine());
        //    int sum = num1 + num2;
        //    Console.WriteLine("The sum of numbers is  " + sum);

        //}
        //static void sqrt()
        //{
        //    Console.WriteLine("Enter the number");
        //    int num1 = Convert.ToInt32(Console.ReadLine());
        //    int sqrt = num1 * num1;
        //    Console.WriteLine("The square root of number is  " + sqrt);

        //}
        //static void Even()
        //{
        //    for (int i = 2; i <= 100; i += 2)
        //    {
        //        Console.WriteLine(i);

        //    }


        //}
        //static void nnumber()
        //{
        //    Console.WriteLine("Enter a number");
        //    int n = Convert.ToInt32(Console.ReadLine());
        //    int sum = 0;
        //    for (int i = 1; i <= n; i++)
        //    {
        //        sum += i;
        //    }
        //    Console.WriteLine("The sum is " + sum);
        //}
        //static void table()
        //{
        //    Console.WriteLine("Enter a number");
        //    int n = Convert.ToInt32(Console.ReadLine());
        //    for (int i = n; i <= 12; i++)
        //    {
        //        for (int j = n; j <= 12; j++)
        //        {
        //            Console.Write(i * j + "\t");

        //        }
        //        Console.WriteLine();
        //    }
        //}
        ////static bool prime(int n)
        ////{

        ////    if (n < 2)
        ////        return false;



        ////    for (int i = 2; i <= Math.Sqrt(n); i++)
        ////    {

        ////            if (n % i == 0)
        ////                return false;


        ////        //Console.WriteLine("the prime numbers upto n are" + i);
        ////    }
        ////    return true;
        ////static void Main()
        ////    {
        ////        Console.WriteLine("Enter a number");
        ////        int n = Convert.ToInt32(Console.ReadLine());
        ////        Console.WriteLine("prime numbers upto " + n + );
        ////        for(int i=2; i<=n;i++)
        ////        {
        ////            if (prime(i))
        ////                Console.WriteLine(i);
        ////        }
        ////    }


        ////}
        //static void prime()
        //{
        //    Console.WriteLine("Enter a number");
        //    string prime = Console.ReadLine();
        //    int number = int.Parse(prime); //Converting String Input to Int
        //    Console.WriteLine("Prime numbers in this range are");
        //    if (number >= 2) // Appending 2 manually to ease the loop
        //    {
        //        Console.WriteLine(2);
        //    }
        //    for (int i = 3; i <= (number); i++) //Starting the Loop from 3 since we added 2 manually
        //    {
        //        bool CheckFlag = true; // using a bool fLAG to check if the number is prime or not

        //        for (int j = 2; j <= (i - 1); j++) //Using Nested Loop to check each number with in the range
        //        {
        //            if (i % j == 0)
        //            {
        //                CheckFlag = false;  //Changing the flag value so that we get our prime numbers only
        //            }
        //        }

        //        if (CheckFlag == true)
        //        {
        //            Console.WriteLine(i);
        //        }
        //    }
        //}
        //static void fact()
        //{ 
        //    Console.WriteLine("enter a number");
        //    int n = Convert.ToInt32(Console.ReadLine());
        //    //if (n == 0)
        //    //    return 1;
        //    //else
        //    //    return n;
        //    int res = 1;
        //    for (int i=1; i<=n; i++)
        //    {
        //        res*= i;
                


        //    }


        //    Console.WriteLine("The factorial of number (n) is" + res);


        //}
        //static void fibo()
        //{
        //    Console.WriteLine("Enter a number");
        //    int n = Convert.ToInt32(Console.ReadLine());
        //    int a = 0, b = 1;
        //    Console.WriteLine("fibo series upto" + n);
        //    Console.Write(a + " ");
        //    for (int i=2; i<=n; i++)
        //    {
        //        Console.Write(b + " ");
        //        int temp = a;
        //        a = b;
        //        b = temp + b;
                
        //    }
        //}
        static bool IsPalindrome(string str)
        {
            int left = 0;
            int right = str.Length - 1;

            while (left < right)
            {
                if (str[left] != str[right])
                    return false;

                left++;
                right--;
            }

            return true;
        }

        static void Main()
        {
            Console.WriteLine("Enter a string:");
            string input = Console.ReadLine();

            bool isPalindrome = IsPalindrome(input);

            Console.WriteLine(isPalindrome ? "The string is a palindrome." : "The string is not a palindrome.");
        }
    }
}
}
