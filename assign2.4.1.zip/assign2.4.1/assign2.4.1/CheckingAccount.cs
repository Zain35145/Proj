﻿using System;
using System.Collections.Generic;
using System.Text;

namespace assign2._4._1
{
    class CheckingAccount : BankAccount, ITransaction
    {
        public CheckingAccount(string accountHolderName)
            : base(accountHolderName)
        {
        }

        public void ExecuteTransaction(decimal amount)
        {
            Withdraw(amount);
        }

        public void PrintTransaction()
        {
            PrintTransactionHistory();
        }
    }
}
