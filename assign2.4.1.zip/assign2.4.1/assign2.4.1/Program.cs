﻿using System;
using System.Collections.Generic;

// Transaction class to hold transaction details


// ITransaction interface with methods for executing a transaction and printing transaction details

// BankAccount class as an abstraction of a bank account


// SavingsAccount class that inherits from BankAccount and realizes the ITransaction interface


// CheckingAccount class that inherits from BankAccount and realizes the ITransaction interface



// LoanAccount class that inherits from BankAccount and realizes the ITransaction interface


// Bank class that manages bank accounts

namespace assign2._4._1
{

    class Program
    {
        static void Main(string[] args)
        {
            Bank bank = new Bank();

            SavingsAccount savingsAccount = new SavingsAccount("John Doe", 2.5m);
            CheckingAccount checkingAccount = new CheckingAccount("Jane Smith");
            LoanAccount loanAccount = new LoanAccount("Sam Johnson", 5.0m);

            bank.AddAccount(savingsAccount);
            bank.AddAccount(checkingAccount);
            bank.AddAccount(loanAccount);

            savingsAccount.Deposit(1000);
            checkingAccount.Deposit(500);
            loanAccount.Deposit(2000);

            bank.ProcessTransaction(savingsAccount.AccountNumber, 200);
            bank.ProcessTransaction(checkingAccount.AccountNumber, 1000);
            bank.ProcessTransaction(loanAccount.AccountNumber, 500);

            savingsAccount.CalculateInterest();
            loanAccount.CalculateInterest();

            savingsAccount.PrintTransaction();
            checkingAccount.PrintTransaction();
            loanAccount.PrintTransaction();

            Console.ReadLine();
        }
    }
}
