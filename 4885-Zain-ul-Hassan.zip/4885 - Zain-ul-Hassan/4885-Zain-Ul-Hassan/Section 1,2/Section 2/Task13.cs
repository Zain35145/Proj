﻿using System;

class Program
{
    static void Main()
    {
        int[] numbers = { 5, 2, 9, 1, 7 }; // Sample array of integers (can be changed)

        int smallest = numbers[0];
        int largest = numbers[0];

        foreach (int number in numbers)
        {
            if (number < smallest)
                smallest = number;

            if (number > largest)
                largest = number;
        }

        Console.WriteLine("Smallest number: " + smallest);
        Console.WriteLine("Largest number: " + largest);
    }
}
