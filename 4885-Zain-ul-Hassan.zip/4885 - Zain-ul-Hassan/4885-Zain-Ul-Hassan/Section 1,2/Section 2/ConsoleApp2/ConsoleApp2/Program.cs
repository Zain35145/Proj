﻿using System;

class Program
{
    static bool IsPalindrome(string str)
    {
        int left = 0;
        int right = str.Length - 1;

        while (left < right)
        {
            if (str[left] != str[right])
                return false;

            left++;
            right--;
        }

        return true;
    }
    // Task 12
    static void Main()
    {
        Console.WriteLine("Enter a string:");
        string input = Console.ReadLine();

        bool isPalindrome = IsPalindrome(input);

        Console.WriteLine(isPalindrome ? "The string is a palindrome." : "The string is not a palindrome.");
        Task13();
        Task14();
        Task15();
        Task16();
        Task17();
        Task18();
        Task19();
        Task20();
    }
    //Task 13
        static void Task13()
        {
            int[] numbers = { 5, 2, 9, 1, 7 }; // Sample array of integers (can be changed)

            int smallest = numbers[0];
            int largest = numbers[0];

            foreach (int number in numbers)
            {
                if (number < smallest)
                    smallest = number;

                if (number > largest)
                    largest = number;
            }

            Console.WriteLine("Smallest number: " + smallest);
            Console.WriteLine("Largest number: " + largest);
        }
    //Task 14
    static void Task14()
    {
        Console.WriteLine("Enter the height of the triangle:");
        int height = Convert.ToInt32(Console.ReadLine());

        for (int i = 1; i <= height; i++)
        {
            for (int j = 1; j <= i; j++)
            {
                Console.Write("*");
            }

            Console.WriteLine();
        }
    }
    //Task 15
    static void Task15()
    {
        Console.WriteLine("Enter the number of rows:");
        int n = Convert.ToInt32(Console.ReadLine());

        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= n - i; j++)
            {
                Console.Write(" ");
            }

            for (int k = 1; k <= 2 * i - 1; k++)
            {
                Console.Write("*");
            }

            Console.WriteLine();
        }
    }
    //Task16
    static string ReverseString(string input)
    {
        char[] charArray = input.ToCharArray();
        int left = 0;
        int right = input.Length - 1;

        while (left < right)
        {
            char temp = charArray[left];
            charArray[left] = charArray[right];
            charArray[right] = temp;

            left++;
            right--;
        }

        return new string(charArray);
    }

    static void Task16()
    {
        Console.WriteLine("Enter a string:");
        string input = Console.ReadLine();

        string reversed = ReverseString(input);

        Console.WriteLine("Reversed string: " + reversed);
    }
    //Task17
    static void Task17()
    {
        Console.WriteLine("Enter the size of the array:");
        int size = Convert.ToInt32(Console.ReadLine());

        int[] numbers = new int[size];

        Console.WriteLine("Enter the numbers:");

        for (int i = 0; i < size; i++)
        {
            numbers[i] = Convert.ToInt32(Console.ReadLine());
        }

        SortArray(numbers);

        Console.WriteLine("Sorted array:");
        foreach (int number in numbers)
        {
            Console.WriteLine(number);
        }
    }

    static void SortArray(int[] arr)
    {
        for (int i = 0; i < arr.Length - 1; i++)
        {
            for (int j = 0; j < arr.Length - i - 1; j++)
            {
                if (arr[j] > arr[j + 1])
                {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
    //Task18
    static void Task18()
    {
        Console.WriteLine("Enter a number:");
        int number = Convert.ToInt32(Console.ReadLine());

        int sum = 0;
        for (int i = 1; i < number; i++)
        {
            if (number % i == 0)
                sum += i;
        }

        if (sum == number)
            Console.WriteLine(number + " is a perfect number.");
        else
            Console.WriteLine(number + " is not a perfect number.");
    }
    //Task 19
    static void Task19()
    {
        Console.WriteLine("Enter the number of rows:");
        int n = Convert.ToInt32(Console.ReadLine());

        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= i; j++)
            {
                Console.Write(j);
            }

            Console.WriteLine();
        }
    }
    //Task20

    static string LongestCommonSubsequence(string str1, string str2)
    {
        int[,] lengths = new int[str1.Length + 1, str2.Length + 1];

        for (int i = 0; i <= str1.Length; i++)
        {
            for (int j = 0; j <= str2.Length; j++)
            {
                if (i == 0 || j == 0)
                    lengths[i, j] = 0;
                else if (str1[i - 1] == str2[j - 1])
                    lengths[i, j] = lengths[i - 1, j - 1] + 1;
                else
                    lengths[i, j] = Math.Max(lengths[i - 1, j], lengths[i, j - 1]);
            }
        }

        int length = lengths[str1.Length, str2.Length];
        char[] result = new char[length];

        int index = length - 1;
        int m = str1.Length;
        int n = str2.Length;

        while (m > 0 && n > 0)
        {
            if (str1[m - 1] == str2[n - 1])
            {
                result[index] = str1[m - 1];
                m--;
                n--;
                index--;
            }
            else if (lengths[m - 1, n] > lengths[m, n - 1])
            {
                m--;
            }
            else
            {
                n--;
            }
        }

        return new string(result);
    }

    static void Task20()
    {
        Console.WriteLine("Enter the first string:");
        string str1 = Console.ReadLine();

        Console.WriteLine("Enter the second string:");
        string str2 = Console.ReadLine();

        string longestCommonSubsequence = LongestCommonSubsequence(str1, str2);

        Console.WriteLine("Longest common subsequence: " + longestCommonSubsequence);
    }
}


 
