﻿using System;
using System.Collections.Generic;
using System.Text;

namespace assign2._4._1
{
    class BankAccount
    {
        public static int accountCount = 0;

        public string AccountNumber { get; }
        public string AccountHolderName { get; }
        public decimal Balance { get; set; }
        private List<Transaction> transactions;

        public BankAccount(string accountHolderName)
        {
            AccountNumber = GenerateAccountNumber();
            AccountHolderName = accountHolderName;
            Balance = 0;
            transactions = new List<Transaction>();
        }

        private string GenerateAccountNumber()
        {
            accountCount++;
            return "ACC" + accountCount.ToString().PadLeft(4, '0');
        }

        public virtual void Deposit(decimal amount)
        {
            if (amount > 0)
            {
                Balance += amount;
                AddTransaction("Deposit", amount);
            }
            else
            {
                Console.WriteLine("Invalid deposit amount.");
            }
        }

        public virtual void Withdraw(decimal amount)
        {
            if (amount > 0 && amount <= Balance)
            {
                Balance -= amount;
                AddTransaction("Withdrawal", -amount);
            }
            else
            {
                Console.WriteLine("Invalid withdrawal amount or insufficient balance.");
            }
        }

        public virtual void CalculateInterest()
        {
            // No interest calculation for BankAccount class
        }

        public void PrintTransactionHistory()
        {
            Console.WriteLine($"Transaction History for Account: {AccountNumber}");
            foreach (Transaction transaction in transactions)
            {
                Console.WriteLine(transaction);
            }
        }

        public void AddTransaction(string description, decimal amount)
        {
            Transaction transaction = new Transaction(description, amount);
            transactions.Add(transaction);
        }
    }
}
